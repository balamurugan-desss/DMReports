﻿using Keyword_Suggesion.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Keyword_Suggesion.Controllers
{
    [LoginCheck]
    public class ProjectCitiesController : Controller
    {
        private string KeywordConnString = ConfigurationManager.ConnectionStrings["KeywordConnection"].ConnectionString;

        // GET: ProjectCities
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ProjectCityList()
        {
            SqlConnection con = new SqlConnection(KeywordConnString);
            SqlCommand cmd = new SqlCommand("proc_ProjectCitylist", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            List<ProjectCity> projectCitylist = new List<ProjectCity>();
            for (int j = 0; j < dataTable.Rows.Count; j++)
            {
                ProjectCity projectCity = new ProjectCity();
                projectCity.Project_city_uid = Convert.ToInt32(dataTable.Rows[j]["project_city_uid"]);

                projectCity.ProjectName = dataTable.Rows[j]["ProjectName"].ToString();
                projectCity.City = dataTable.Rows[j]["CityName"].ToString();


                projectCitylist.Add(projectCity);

            }
            return View(projectCitylist);
        }

        [HttpGet]
        public ActionResult CreateProjectCitytName()
        {
            ProjectCity projectCity = new ProjectCity();

            projectCity.CityNameList = ListCityName();
            return View(projectCity);
        }
        [HttpPost]
        public ActionResult CreateProjectCitytName(ProjectCity projectCity)
        {
            if (!ModelState.IsValid)
                return View(projectCity);

            string Cities = string.Empty;
            if (projectCity.CityName != null)
            {
                Cities = ConvertStringArrayToString(projectCity.CityName);
            }
            
            SqlConnection con = new SqlConnection(KeywordConnString);
            SqlCommand cmd = new SqlCommand("proc_CreateProjectCity", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProjectName", projectCity.ProjectName);
            cmd.Parameters.AddWithValue("@CityName", Cities);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("ProjectCityList");
        }

        [HttpGet]
        public ActionResult UpdateProjectCityName(int id)
        {
            SqlConnection con = new SqlConnection(KeywordConnString);
            SqlCommand cmd = new SqlCommand("proc_EditProjectCity", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@project_city_uid", id);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            ProjectCity projectCity = new ProjectCity();
            projectCity.ProjectName = dataTable.Rows[0]["ProjectName"].ToString();
            if (!string.IsNullOrEmpty(dataTable.Rows[0]["Cityname"].ToString()))
            {
                projectCity.CityNameList = ListCityName();
                string City = dataTable.Rows[0]["Cityname"].ToString();
                projectCity.CityName = City.Split(',');
                for (int i = 0; i < projectCity.CityName.Length; i++)
                {

                    foreach (var item in projectCity.CityNameList)
                    {
                        if (projectCity.CityName[i] == item.Text.ToString())
                        {
                            item.Selected = true;
                        }
                    }
                }
            }
            return View(projectCity);
        }
        [HttpPost]
        public ActionResult UpdateProjectCityName(ProjectCity projectCity)
        {
            if (!ModelState.IsValid)
                return View(projectCity);

            string Cities = string.Empty;
            if (projectCity.CityName != null)
            {
                Cities = ConvertStringArrayToString(projectCity.CityName);
            }

            SqlConnection con = new SqlConnection(KeywordConnString);
            SqlCommand cmd = new SqlCommand("proc_UpdateCity", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Cityname", projectCity.ProjectName);
            cmd.Parameters.AddWithValue("@State", Cities);
            cmd.Parameters.AddWithValue("@CityId", projectCity.Project_city_uid);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("CityList");
        }


        public static List<SelectListItem> ListCityName()
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["KeywordConnection"].ConnectionString);

            List<SelectListItem> CityList = new List<SelectListItem>();
            {
                string query = "select CityName from tblCities group by CityName ";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    CityList.Add(new SelectListItem
                    {

                        Text = dt.Rows[i]["CityName"].ToString(),
                        Value = dt.Rows[i]["CityName"].ToString()
                    });
                }
            }

            return CityList;

        }
        public string ConvertStringArrayToString(string[] array)
        {
            // Concatenate all the elements into a StringBuilder.
            StringBuilder builder = new StringBuilder();
            foreach (string value in array)
            {
                builder.Append(value);
                builder.Append(',');
            }
            return builder.ToString().TrimEnd(',');
        }

        public ActionResult DeleteProjectCities(string Id)
        {
            try
            {
                SqlConnection con = new SqlConnection(KeywordConnString);
                SqlCommand cmd = new SqlCommand("proc_deletetblProjectCities", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@project_city_uid", Id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                return RedirectToAction("ProjectCityList");

            }
            catch (Exception ex)

            {
                return View(ex);

            }
        }

    }
}